export class Employee{
    constructor(public Name:string, public id:string,public task:string,public deadline:string ){

    }
}